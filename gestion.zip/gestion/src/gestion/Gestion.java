/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package gestion;

/*@author santi*/
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
public class Gestion {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String usuario="root";
        String password="pernia10";
        String url="jdbc:mysql://localhost:3306/gestionrestaurante";
        Connection conexion;
        Statement statement;
        ResultSet rs;
        
        
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Gestion.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            conexion=DriverManager.getConnection(url,usuario,password);
            statement=conexion.createStatement();
            rs=statement.executeQuery("SELECT * FROM USUARIOS");
            rs.next();
            do{
                System.out.println(rs.getInt("idusuarios")+":"+ rs.getString("nombre"));
            }while (rs.next());
            
            // insert
            statement.executeUpdate("INSERT INTO USUARIOS VALUES (6,'Victor Saa','Victor@gmail.com','1410')");
            System.out.println("");
            rs=statement.executeQuery("SELECT * FROM USUARIOS");
            rs.next();
            do{
                System.out.println(rs.getInt("idusuarios")+":"+ rs.getString("nombre"));
            }while (rs.next());
            
            //Update
            statement.executeUpdate("UPDATE usuarios SET nombre='Maria Valencia' WHERE idusuarios=4");
            System.out.println("");
            rs=statement.executeQuery("SELECT * FROM USUARIOS");
            rs.next();
            do{
                System.out.println(rs.getInt("idusuarios")+":"+ rs.getString("nombre"));
            }while (rs.next());
            
            //Delete 
            statement.executeUpdate("DELETE from usuarios WHERE idusuarios=4");
            System.out.println("");
            rs=statement.executeQuery("SELECT * FROM USUARIOS");
            rs.next();
            do{
                System.out.println(rs.getInt("idusuarios")+":"+ rs.getString("nombre"));
            }while (rs.next());
        } catch (SQLException ex) {
            Logger.getLogger(Gestion.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
