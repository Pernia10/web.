
package com.LaComisaria.pedido.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import java.time.LocalDateTime;
import lombok.Data;

@Entity

@Data
public class turnos {
    
    @Id
    
    @Column
    private int idTurno;
    
    @Column
    private LocalDateTime TurnoDisponible;
    
    
}
