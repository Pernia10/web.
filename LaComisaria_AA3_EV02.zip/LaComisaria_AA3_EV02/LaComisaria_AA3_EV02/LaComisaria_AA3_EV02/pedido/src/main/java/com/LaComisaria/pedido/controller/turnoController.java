
package com.LaComisaria.pedido.controller;

import com.LaComisaria.pedido.model.turnos;
import com.LaComisaria.pedido.service.turnoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/turno")
public class turnoController {
    
    @Autowired
    private turnoService turnoService;
    
    @PostMapping("/nuevo")
    public turnos Newturno (@RequestBody turnos Newturno) {
        return this.turnoService.Newturno(Newturno);
    }
    
    @GetMapping("/mostrar")
    public Iterable<turnos> getAll() {
        return turnoService.getAll();
    } 
    
    @PostMapping("/modificar")
    public turnos updateTurno(@RequestBody turnos turnos){
        return this.turnoService.modifyturnos(turnos);
    }
    
    @PostMapping(value = "/{id}")
    public Boolean deleteTurno(@PathVariable(value="id") Integer id) {
        return this.turnoService.deleteturnos(id);
    }
}
  
