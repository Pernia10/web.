
package com.LaComisaria.pedido.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import java.sql.Time;
import lombok.Data;

@Entity
@Data
public class horario {
    @Id
    
   @Column
    private int idHorario;
    
    @Column 
    private String nombreHorario;
    
    @Column
    private Time tiempoInicio;
    
    @Column
    private Time tiempoFin;
    
}
