
package com.LaComisaria.pedido.service;

import com.LaComisaria.pedido.model.asistencia;
import com.LaComisaria.pedido.repository.asistenciaRepository;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class asistenciaImplement implements asistenciaService{
    
    // La anotación @Autowired permite la inyección automática del repositorio de categorías
    @Autowired
    private asistenciaRepository asistenciaRepository;
    
    // Implementación del método para crear una nueva categoría
    @Override
    public asistencia Newasistencia(asistencia Newasistencia) {
        
        // Guarda la nueva categoría en la base de datos y la devuelve
        return asistenciaRepository.save(Newasistencia);
    }

     // Implementación del método para obtener todas las categorías
    @Override
    public Iterable<asistencia> getAll() {
        
        // Devuelve todas las categorías encontradas en la base de datos
        return this.asistenciaRepository.findAll();
    }

    // Implementación del método para modificar una categoría existente
    @Override
    public asistencia modifyasistencia(asistencia asistencia) {
        
        // Busca la categoría en la base de datos por su ID
        Optional<asistencia> asistenciaEncontrado = this.asistenciaRepository.findById(asistencia.getIdAsistencia());
        
         // Si la categoría existe, se actualizan sus datos
        if (asistenciaEncontrado.get()!= null) {
            
            // Actualiza el nombre y la descripción de la categoría encontrada
            asistenciaEncontrado.get().setFechaHora_inicio(asistencia.getFechaHora_inicio());
            asistenciaEncontrado.get().setFechaHora_fin(asistencia.getFechaHora_fin());
            asistenciaEncontrado.get().setIdEmpleado(asistencia.getIdEmpleado());

            // Guarda los cambios y devuelve la categoría actualizada
            return this.Newasistencia(asistenciaEncontrado.get());
    }
        // Si la categoría no existe, devuelve null
        return null;
    }

    // Implementación del método para eliminar una categoría por su ID
    @Override
    public Boolean deleteasistencia(Integer idAsistencia) {
        
        // Elimina la categoría de la base de datos por su ID
        this.asistenciaRepository.deleteById(idAsistencia);
        
        // Devuelve true indicando que la operación fue exitosa       
        return true;
    }

    
}
