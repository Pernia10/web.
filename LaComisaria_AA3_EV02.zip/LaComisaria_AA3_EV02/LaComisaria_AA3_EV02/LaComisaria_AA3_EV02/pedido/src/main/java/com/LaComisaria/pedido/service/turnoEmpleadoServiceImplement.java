
package com.LaComisaria.pedido.service;

import com.LaComisaria.pedido.model.turnoEmpleado;
import com.LaComisaria.pedido.repository.turnoEmpleadoRepository;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class turnoEmpleadoServiceImplement implements turnoEmpleadoService {
    
    @Autowired
    private turnoEmpleadoRepository turnoEmpleadoRepository; 

    @Override
    public turnoEmpleado NewTurnoEmpleado(turnoEmpleado NewTurnoEmpleado) {
        return turnoEmpleadoRepository.save(NewTurnoEmpleado);
    }

    @Override
    public Iterable<turnoEmpleado> getAll() {
        return this.turnoEmpleadoRepository.findAll();
    }

    @Override
    public turnoEmpleado modifyTurnoEmpleado(turnoEmpleado turnoEmpleado) {
        Optional<turnoEmpleado> turnoEmpleadoEncontrado = this.turnoEmpleadoRepository.findById(turnoEmpleado.getIdTurnoEmpleado());
        if (turnoEmpleadoEncontrado.get() != null) {
            turnoEmpleadoEncontrado.get().setIdEmpleado(turnoEmpleado.getIdEmpleado());
            turnoEmpleadoEncontrado.get().setIdTurno(turnoEmpleado.getIdTurno());
            return this.NewTurnoEmpleado(turnoEmpleadoEncontrado.get());
        }
        return null;
    }

    @Override
    public Boolean deleteTurnoEmpleado(Integer idTurnoEmpleado) {
        this.turnoEmpleadoRepository.deleteById(idTurnoEmpleado);
        return true;
    }
    
}
