
package com.LaComisaria.pedido.model;

//

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Data;

@Entity
@Data
public class empleado {
    @Id
    @Column ( name = "Id Empleado")
    private int idempleado;
    
    @Column ( name = "Nombres", nullable = false)
    private String nombre;
    
    @Column ( name = "Apellidos", nullable = false)
    private String apellidos;
    
    @Column ( nullable = false)
    private String cargo;
    
    @Column ( unique = true, nullable = false, length = 25)
    private String correo;
    
    @Column ( nullable = false, length = 10)
    private Long telefono;
    
}
