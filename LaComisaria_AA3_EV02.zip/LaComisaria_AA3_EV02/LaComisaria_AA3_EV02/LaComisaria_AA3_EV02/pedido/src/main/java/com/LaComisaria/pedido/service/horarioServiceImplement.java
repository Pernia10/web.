
package com.LaComisaria.pedido.service;

import com.LaComisaria.pedido.model.horario;
import com.LaComisaria.pedido.repository.horarioRepository;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class horarioServiceImplement implements horarioService{
    
    @Autowired
    private horarioRepository horarioRepository;

    @Override
    public horario NewHorarios(horario NewHorarios) {
        return horarioRepository.save(NewHorarios);
    }

    @Override
    public Iterable<horario> getAll() {
        return this.horarioRepository.findAll();
    }

    @Override
    public horario modifyHorario(horario horario) {
        Optional<horario> horarioEncontrado = this.horarioRepository.findById(horario.getIdHorario());
        
         // Si la categoría existe, se actualizan sus datos
        if (horarioEncontrado.get()!= null) {
            
            // Actualiza el nombre y la descripción de la categoría encontrada
            horarioEncontrado.get().setNombreHorario(horario.getNombreHorario());
            horarioEncontrado.get().setTiempoInicio(horario.getTiempoInicio());
            horarioEncontrado.get().setTiempoFin(horario.getTiempoFin());
            // Guarda los cambios y devuelve la categoría actualizada
            return this.NewHorarios(horarioEncontrado.get());
    }
        return null;
    }

    @Override
    public Boolean deleteHorario(Integer idHorario) {
        
        // Elimina la categoría de la base de datos por su ID
        this.horarioRepository.deleteById(idHorario);
        return true;
    }
    
}
