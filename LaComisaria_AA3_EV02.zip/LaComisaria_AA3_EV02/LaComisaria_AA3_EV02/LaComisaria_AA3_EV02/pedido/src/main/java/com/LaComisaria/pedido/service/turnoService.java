
package com.LaComisaria.pedido.service;

import com.LaComisaria.pedido.model.turnos;

public interface turnoService {
    turnos Newturno (turnos Newturno);
    Iterable<turnos> getAll();
    turnos modifyturnos (turnos turno);
    Boolean deleteturnos (Integer idTurno);
}
