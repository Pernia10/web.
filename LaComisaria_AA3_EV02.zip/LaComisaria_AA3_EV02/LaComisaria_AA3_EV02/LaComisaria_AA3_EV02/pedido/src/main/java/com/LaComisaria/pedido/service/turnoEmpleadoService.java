
package com.LaComisaria.pedido.service;

import com.LaComisaria.pedido.model.turnoEmpleado;

public interface turnoEmpleadoService  {
    turnoEmpleado NewTurnoEmpleado (turnoEmpleado NewTurnoEmpleado);
    Iterable<turnoEmpleado> getAll();
    turnoEmpleado modifyTurnoEmpleado (turnoEmpleado turnoEmpleado);
    Boolean deleteTurnoEmpleado (Integer idTurnoEmpleado);
}
